export { default as Adw } from 'gi://Adw';
export { default as Gdk } from 'gi://Gdk';
export { default as Gio } from 'gi://Gio';
export { default as GLib } from 'gi://GLib';
export { default as GObject } from 'gi://GObject';
export { default as Gtk } from 'gi://Gtk';
